@echo off
title InmoRadar Colombia - Servidor Local
cd /d "%~dp0"

echo ======================================================
echo    INMORADAR COLOMBIA - INICIANDO SISTEMA
echo    Acceso web: http://127.0.0.1:8000
echo ======================================================
echo.

:: 1. Detect Python binary explicitly
set "PY_EXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
) else if exist "%ProgramFiles%\Python312\python.exe" (
    set "PY_EXE=%ProgramFiles%\Python312\python.exe"
) else if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set "PY_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
) else (
    where python >nul 2>nul
    if %ERRORLEVEL% equ 0 (
        set "PY_EXE=python"
    )
)

if "%PY_EXE%"=="" (
    echo [ERROR CRITICO] No se encontro Python 3 instalado en el equipo.
    echo Por favor asegurese de tener Python 3.12 instalado.
    pause
    exit /b 1
)

echo [OK] Utilizando interprete Python: %PY_EXE%
echo [OK] Verificando dependencias...

:: 2. Pre-check port 8000 and free if stale
powershell -NoProfile -Command "try { $conn = Get-NetTCPConnection -LocalPort 8000 -ErrorAction SilentlyContinue; if ($conn) { Stop-Process -Id $conn.OwningProcess -Force -ErrorAction SilentlyContinue } } catch {}"

:: 3. Smart browser opener (waits until server is healthy, never opens too early)
start /b "" powershell -NoProfile -Command "$ProgressPreference = 'SilentlyContinue'; for ($i=0; $i -lt 40; $i++) { try { $r = Invoke-WebRequest -Uri 'http://127.0.0.1:8000/api/health' -UseBasicParsing -TimeoutSec 1; if ($r.StatusCode -eq 200) { Start-Process 'http://127.0.0.1:8000'; break; } } catch {}; Start-Sleep -Milliseconds 400 }"

echo [OK] Iniciando servidor FastAPI / Uvicorn en http://127.0.0.1:8000 ...
echo [INFO] El navegador se abrira automaticamente en cuanto el servidor responda.
echo [INFO] Presione CTRL+C en esta ventana para detener el servidor.
echo.

"%PY_EXE%" -m uvicorn backend.main:app --host 127.0.0.1 --port 8000

if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] El servidor finalizo con codigo de error %ERRORLEVEL%.
    pause
)
