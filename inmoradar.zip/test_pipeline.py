"""
Test Runner for InmoRadar Colombia pipeline.
Demonstrates loading benchmarks, evaluating property listings, and running the opportunity engine.
"""

import sys
import json
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent))

from backend.models import PropertyListing, ColombianLocation, PropertyType, PortalSource
from backend.opportunity_engine import OpportunityEngine
from backend.deduplication import DeduplicationEngine


def main():
    print("=" * 65)
    print("   INMORADAR COLOMBIA - PRUEBA DE MOTOR DE VALORACIÓN Y RADAR")
    print("=" * 65)

    engine = OpportunityEngine()
    print(f"[OK] Base de conocimiento cargada con {len(engine.benchmarks)} benchmarks urbanos.")

    # Load sample opportunities
    sample_path = Path(__file__).parent / "data" / "sample_opportunities.json"
    with open(sample_path, "r", encoding="utf-8") as f:
        samples = json.load(f)

    print(f"[OK] Procesando {len(samples)} ofertas inmobiliarias de muestra...")
    print("-" * 65)

    analyzed_props = []
    for item in samples:
        prop = PropertyListing(
            id=item["id"],
            portal=PortalSource.FINCARAIZ if "fincaraiz" in item["portal"].lower() else PortalSource.METROCUADRADO,
            external_id=item["id"],
            url=item.get("url", ""),
            title=item["title"],
            property_type=PropertyType.APARTMENT,
            location=ColombianLocation(
                city=item["city"],
                neighborhood=item["neighborhood"],
                estrato=item["estrato"]
            ),
            price_cop=float(item["price_cop"]),
            built_area_m2=float(item["built_area_m2"]),
            bedrooms=item["bedrooms"],
            bathrooms=item["bathrooms"],
            parking_spots=item["parking_spots"],
            stratum=item["estrato"],
            admin_fee_cop=float(item.get("admin_fee_cop", 0)),
            property_age_years=item.get("property_age_years"),
            days_on_market=item.get("days_on_market", 5)
        )

        analysis = engine.analyze_property(prop)
        analyzed_props.append((prop, analysis))

        print(f"Propiedad: {prop.title[:45]}...")
        print(f"  • Ubicación:     {prop.location.neighborhood}, {prop.location.city} (Estrato {prop.stratum})")
        print(f"  • Precio:        ${prop.price_cop:,.0f} COP (${prop.price_per_m2:,.0f}/m²)")
        print(f"  • Descuento M²:  {analysis.discount_vs_neighborhood_pct}% vs mediana barrio")
        print(f"  • Yield Bruto:   {analysis.gross_annual_rental_yield_pct}% anual")
        print(f"  • Score Radar:   {analysis.opportunity_score} / 100 [{analysis.confidence_level}]")
        print(f"  • Estrategia:    {analysis.recommended_strategy.value}")
        print("-" * 65)

    print("\n[VERIFICACIÓN DE CLUSTERING / ARBITRAJE ENTRE PORTALES]")
    clusters = DeduplicationEngine.cluster_listings([p[0] for p in analyzed_props])
    print(f"Total agrupaciones únicas: {len(clusters)}")
    for cl in clusters:
        if cl["price_discrepancy_cop"] > 0:
            print(f"  >>> ALERTA DE ARBITRAJE: {cl['negotiation_tip']}")

    print("\n[PROCESO COMPLETADO SATISFACTORIAMENTE]")


if __name__ == "__main__":
    main()
